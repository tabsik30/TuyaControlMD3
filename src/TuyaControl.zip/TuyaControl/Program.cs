using MacroDeck.Plugin.Hosting;
using Microsoft.Extensions.DependencyInjection;
using TuyaControl.Services;

namespace TuyaControl;

public static class Program
{
    public static async Task Main(string[] args)
    {
        var builder = MacroDeckPlugin.CreatePlugin(args)
            .UseMacroDeckLogging()
            .RegisterIntegration<PluginIntegration>();

        // Shared singletons: one cloud session and one device store for the whole
        // plugin process, used by the config flow, actions, and TuyaLocalClient's
        // cloud-fallback path alike.
        // Loaded synchronously and registered as an existing instance (not via
        // AddSingleton<TuyaDeviceStore>()) so the very first capability declaration -
        // which happens before InitializeAsync ever runs - already sees last-known
        // devices/account. See TuyaDeviceStore's class remarks for why this matters.
        var deviceStore = new TuyaDeviceStore();
        deviceStore.LoadLocalCache();
        builder.Services.AddSingleton(deviceStore);

        builder.Services.AddSingleton<TuyaCloudClient>();
        builder.Services.AddSingleton<TuyaLocalClient>();
        builder.Services.AddHostedService<TuyaStatusPollingService>();

        var plugin = builder.Build();
        await plugin.RunAsync();
    }
}
