using System.Collections.Concurrent;
using System.Text.Json;
using MacroDeck.Sdk;
using TuyaControl.Models;

namespace TuyaControl.Services;

/// <summary>
/// Each device is one MD3 config-flow entry (kind="device") in the HOST's config
/// store, the cloud account is one entry (kind="account") - see
/// ConfigFlow/TuyaConfigFlow.cs for where entries are written, and
/// PluginIntegration.InitializeAsync for where they're loaded back, via
/// LoadFromHostAsync. The host's config store is the source of truth.
///
/// PROBLEM this file's local cache works around: capability declaration (which
/// variables/actions get advertised to the host) happens once per connection,
/// always BEFORE InitializeAsync runs on that same connection - confirmed from the
/// decompiled PluginConnectionHostedService (OpenSessionAsync, which declares
/// capabilities, precedes the WebSocket "Connected" event that triggers
/// InitializeAsync). A per-device state variable (see PluginIntegration) is only
/// declared for devices already in this store AT THAT MOMENT. Since
/// LoadFromHostAsync only runs after InitializeAsync fires, a device added in a
/// previous run would still be invisible to the FIRST declaration of a freshly
/// started process - restarting the plugin process does NOT fix this, because a
/// fresh process repeats exactly the same empty-store-at-declare-time sequence.
///
/// Fix: LoadLocalCache() reads a small JSON mirror of devices+account from disk
/// SYNCHRONOUSLY in Program.cs, before the host builder even starts connecting - so
/// the store already has last-known devices by the time the very first capability
/// declaration happens. SaveLocalCache() is called after every config flow write to
/// keep that mirror current. The host's config store remains authoritative:
/// LoadFromHostAsync (in InitializeAsync) still runs and overwrites entries by id, so
/// any drift self-corrects once the connection is up.
/// </summary>
public sealed class TuyaDeviceStore
{
    private static readonly string CacheDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "MacroDeck", "plugins", "com.tabsik12.tuya-control");

    private static readonly string CachePath = Path.Combine(CacheDirectory, "devices-cache.json");

    private readonly ConcurrentDictionary<string, TuyaDeviceRecord> _devices = new(StringComparer.Ordinal);

    // Cache of the last polled state per device, filled by TuyaStatusPollingService.
    // Never persisted to disk - not needed at declare time, only actual live status.
    private readonly ConcurrentDictionary<string, bool?> _state = new(StringComparer.Ordinal);
    private readonly ConcurrentDictionary<string, bool> _reachable = new(StringComparer.Ordinal);

    public TuyaRegion? AccountRegion { get; private set; }
    public string? AccountCountryCode { get; private set; }
    public string? AccountUsername { get; private set; }
    public string? AccountPassword { get; private set; }
    public string AccountSchema { get; private set; } = "tuyaSmart";
    public string? AccountClientId { get; private set; }
    public string? AccountClientSecret { get; private set; }

    public bool HasAccount => AccountUsername is not null;

    public IReadOnlyList<TuyaDeviceRecord> Devices => [.. _devices.Values];

    public TuyaDeviceRecord? GetById(string deviceId) =>
        _devices.TryGetValue(deviceId, out var device) ? device : null;

    public void SetDevice(TuyaDeviceRecord device) => _devices[device.Id] = device;

    public bool? GetState(string deviceId) => _state.GetValueOrDefault(deviceId);

    public bool IsReachable(string deviceId) => _reachable.GetValueOrDefault(deviceId);

    public void SetState(string deviceId, bool? state, bool reachable)
    {
        _state[deviceId] = state;
        _reachable[deviceId] = reachable;
    }

    public void SetAccount(TuyaRegion region, string countryCode, string username, string password, string schema, string clientId, string clientSecret)
    {
        AccountRegion = region;
        AccountCountryCode = countryCode;
        AccountUsername = username;
        AccountPassword = password;
        AccountSchema = schema;
        AccountClientId = clientId;
        AccountClientSecret = clientSecret;
    }

    /// <summary>
    /// Reads every config entry the host has stored for this plugin and rebuilds the
    /// in-memory device list + account settings. Call once from
    /// PluginIntegration.InitializeAsync. This is the authoritative load - it
    /// overwrites whatever LoadLocalCache() bootstrapped with.
    /// </summary>
    public async Task LoadFromHostAsync(IIntegrationContext context)
    {
        var entries = await context.Config.GetEntriesAsync();
        foreach (var entry in entries)
        {
            var kind = await context.Config.GetStringAsync(entry.Id, "kind");
            if (kind == "device")
            {
                var id = await context.Config.GetStringAsync(entry.Id, "id");
                var name = await context.Config.GetStringAsync(entry.Id, "name");
                if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(name))
                {
                    continue;
                }

                var localKey = await context.Config.GetSecretAsync(entry.Id, "localKey");
                var ip = await context.Config.GetStringAsync(entry.Id, "ipAddress") ?? "";
                var protocolVersion = await context.Config.GetStringAsync(entry.Id, "protocolVersion") ?? "3.3";
                var primaryCode = await context.Config.GetStringAsync(entry.Id, "primaryCode");
                if (string.IsNullOrWhiteSpace(primaryCode))
                {
                    primaryCode = "switch_1";
                }

                SetDevice(new TuyaDeviceRecord
                {
                    Id = id,
                    Name = name,
                    LocalKey = localKey,
                    IpAddress = ip,
                    ProtocolVersion = protocolVersion,
                    PrimaryCode = primaryCode,
                });
            }
            else if (kind == "account")
            {
                var regionText = await context.Config.GetStringAsync(entry.Id, "region");
                var countryCode = await context.Config.GetStringAsync(entry.Id, "countryCode");
                var username = await context.Config.GetStringAsync(entry.Id, "username");
                var password = await context.Config.GetSecretAsync(entry.Id, "password");
                var schema = await context.Config.GetStringAsync(entry.Id, "schema");
                var clientId = await context.Config.GetStringAsync(entry.Id, "clientId");
                var clientSecret = await context.Config.GetSecretAsync(entry.Id, "clientSecret");

                if (Enum.TryParse<TuyaRegion>(regionText, out var region) &&
                    !string.IsNullOrWhiteSpace(username) && !string.IsNullOrWhiteSpace(password) &&
                    !string.IsNullOrWhiteSpace(clientId) && !string.IsNullOrWhiteSpace(clientSecret))
                {
                    SetAccount(region, countryCode ?? "48", username, password, schema ?? "tuyaSmart", clientId, clientSecret);
                }
            }
        }

        // Whatever the host just confirmed is now current - refresh the fast-bootstrap
        // mirror too, so the next process start sees it without waiting on the host.
        SaveLocalCache();
    }

    /// <summary>
    /// Synchronous, best-effort. Call once in Program.cs before the host builder
    /// starts connecting, so the very first capability declaration already sees
    /// last-known devices/account instead of an empty store.
    /// </summary>
    public void LoadLocalCache()
    {
        try
        {
            if (!File.Exists(CachePath))
            {
                return;
            }

            var json = File.ReadAllText(CachePath);
            var snapshot = JsonSerializer.Deserialize<CacheSnapshot>(json);
            if (snapshot is null)
            {
                return;
            }

            foreach (var device in snapshot.Devices ?? [])
            {
                if (!string.IsNullOrWhiteSpace(device.Id) && !string.IsNullOrWhiteSpace(device.Name))
                {
                    SetDevice(device);
                }
            }

            if (snapshot.Account is { } account &&
                Enum.TryParse<TuyaRegion>(account.Region, out var region) &&
                !string.IsNullOrWhiteSpace(account.Username) && !string.IsNullOrWhiteSpace(account.Password) &&
                !string.IsNullOrWhiteSpace(account.ClientId) && !string.IsNullOrWhiteSpace(account.ClientSecret))
            {
                SetAccount(region, account.CountryCode ?? "48", account.Username, account.Password,
                    account.Schema ?? "tuyaSmart", account.ClientId, account.ClientSecret);
            }
        }
        catch (Exception)
        {
            // Best-effort bootstrap cache - if it's missing or corrupt, InitializeAsync's
            // LoadFromHostAsync will populate everything correctly once connected anyway.
        }
    }

    /// <summary>Best-effort. Call after every successful config flow write.</summary>
    public void SaveLocalCache()
    {
        try
        {
            Directory.CreateDirectory(CacheDirectory);
            var snapshot = new CacheSnapshot
            {
                Devices = [.. _devices.Values],
                Account = HasAccount
                    ? new CacheAccount
                    {
                        Region = AccountRegion?.ToString(),
                        CountryCode = AccountCountryCode,
                        Username = AccountUsername,
                        Password = AccountPassword,
                        Schema = AccountSchema,
                        ClientId = AccountClientId,
                        ClientSecret = AccountClientSecret,
                    }
                    : null,
            };

            File.WriteAllText(CachePath, JsonSerializer.Serialize(snapshot));
        }
        catch (Exception)
        {
            // Best-effort - a failed write just means the next process start falls back
            // to waiting for LoadFromHostAsync, same as before this cache existed.
        }
    }

    private sealed class CacheSnapshot
    {
        public List<TuyaDeviceRecord>? Devices { get; set; }
        public CacheAccount? Account { get; set; }
    }

    private sealed class CacheAccount
    {
        public string? Region { get; set; }
        public string? CountryCode { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
        public string? Schema { get; set; }
        public string? ClientId { get; set; }
        public string? ClientSecret { get; set; }
    }
}
