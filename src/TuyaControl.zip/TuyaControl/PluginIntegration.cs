using MacroDeck.Sdk;
using MacroDeck.Sdk.Actions;
using MacroDeck.Sdk.ConfigFlow;
using MacroDeck.Sdk.Variables;
using TuyaControl.Actions;
using TuyaControl.ConfigFlow;
using TuyaControl.Services;

namespace TuyaControl;

/// <summary>
/// The MD2 plugin exposed no variables, only actions plus its two config windows
/// (now one IConfigFlow, see ConfigFlow/TuyaConfigFlow.cs). IVariableProvider was
/// added afterward so two-state buttons can reflect a device's real on/off state
/// even when it was changed outside Macro Deck (Tuya app, physical switch) - see
/// TuyaStatusPollingService for how the state gets kept fresh.
///
/// ProvidedVariables is a COMPUTED property (not an object-initializer list) because
/// it's built from store.Devices, which is only populated once InitializeAsync runs -
/// and capability declaration happens once per connection, always before
/// InitializeAsync completes on that same connection. In practice this means: on the
/// very first connection of a freshly started process, no per-device state variables
/// are declared yet (store.Devices is still empty at declare time). From the next
/// reconnect onward (same process) they're there, since the store is an in-memory
/// singleton that persists across reconnects. If a freshly-added device's state
/// variable doesn't show up, restarting the plugin process is the fix.
/// </summary>
internal sealed class PluginIntegration(
    TuyaDeviceStore store,
    TuyaCloudClient cloudClient,
    TuyaLocalClient localClient,
    IIntegrationContext context)
    : IPluginIntegration, IVariableProvider, IConfigFlowProvider
{
    private const string NamePrefix = "device_";
    private const string NameSuffix = "_state";

    public IReadOnlyList<IActionDefinition> Actions { get; } =
    [
        new ToggleSwitchAction(store, localClient),
        new SetSwitchStateAction(store, localClient),
        new SendCustomCommandAction(store, localClient),
        new DetectDeviceAction(store, context),
    ];

    public async Task InitializeAsync(IIntegrationContext integrationContext)
    {
        await store.LoadFromHostAsync(integrationContext);

        // Re-establish a cloud session immediately if an account was already
        // configured in a previous run, so cloud-fallback devices ("cloud" protocol
        // version) work right away without requiring the user to re-open the config
        // flow's account step.
        if (store.HasAccount && store.AccountRegion.HasValue)
        {
            cloudClient.Configure(store.AccountRegion.Value, store.AccountClientId!, store.AccountClientSecret!);
            cloudClient.CountryCode = store.AccountCountryCode!;
            cloudClient.Username = store.AccountUsername;
            cloudClient.Password = store.AccountPassword;
            cloudClient.Schema = store.AccountSchema;
        }
    }

    public Task ShutdownAsync() => Task.CompletedTask;

    // --- IVariableProvider ---

    public IReadOnlyList<ProvidedVariable> ProvidedVariables =>
        store.Devices
            .Select(d => new ProvidedVariable(StateVariableName(d.Id), VariableType.Boolean, RefreshInterval: TimeSpan.FromSeconds(2)))
            .ToList();

    public Task<object?> GetValueAsync(string name, CancellationToken cancellationToken)
    {
        if (name.StartsWith(NamePrefix, StringComparison.Ordinal) && name.EndsWith(NameSuffix, StringComparison.Ordinal))
        {
            var deviceId = name[NamePrefix.Length..^NameSuffix.Length];
            if (store.GetById(deviceId) is not null)
            {
                // Unreachable/never-polled reports as "off" rather than erroring the
                // variable out - a two-state button just shows its off appearance.
                return Task.FromResult<object?>(store.GetState(deviceId) ?? false);
            }
        }

        return Task.FromResult<object?>(null);
    }

    private static string StateVariableName(string deviceId) => $"{NamePrefix}{deviceId}{NameSuffix}";

    // --- IConfigFlowProvider ---

    public IConfigFlow CreateConfigFlow() => new TuyaConfigFlow(cloudClient, store);
}
