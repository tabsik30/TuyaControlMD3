# Tuya Control — MD3

## Jak to wstawić do prawdziwego projektu

1. `dotnet new macrodeck-plugin -n TuyaControl --pluginId com.tabsik12.tuya-control --pluginName "Tuya Control"`
2. Podmień wygenerowane `manifest.json`, `Program.cs`, `PluginIntegration.cs`
3. Dorzuć `Services/`, `ConfigFlow/`, `Actions/`, `Models/`, `Assets/icon.svg`
4. **WAŻNE — dodaj referencję do NuGet, której nie ma w domyślnym szablonie:**
   ```
   dotnet add package Newtonsoft.Json
   ```
   Cała logika chmury/LAN używa `JObject`/`JArray`/`JToken` tak jak oryginał — bez tego
   pakietu build się nie skompiluje. (Widziałem `newtonsoft.json` w Twoim folderze
   `.nuget\packages`, więc na pewno już go kiedyś pobierałeś do MD2.)
5. Sprawdź w `manifest.json` czy `entrypoints.win-x64.executable` zgadza się z
   rzeczywistą nazwą `.exe` po `dotnet publish` (jak przy ETS2/MacroLink)

## Client ID/Secret podawane w konfiguracji, nie w kodzie

W przeciwieństwie do oryginału (`TuyaAppCredentials` z zaszytym na sztywno Client
Secret), teraz każdy wpisuje **własny** Client ID (Access ID) i Client Secret (Access
Secret) w kroku "Tuya cloud account" config flow — dokładnie tak jak login/hasło.
Dzięki temu plugin można spokojnie udostępnić bez przebudowywania, i bez ryzyka
wycieku Twojego sekretu. Dane bierze się z panelu iot.tuya.com → Cloud → Development
→ (Twój projekt) → Overview.

## Co jest pewne (przeniesione 1:1 z działającego kodu MD2)

- Cały protokół LAN 3.3/3.4 (`TuyaLocalClient.cs`) i 3.5 AES-GCM (`TuyaLocalClientV35.cs`)
  — ramkowanie pakietów, CRC32, negocjacja klucza sesji, PKCS7 — bez zmian logiki
- UDP discovery (`TuyaDiscovery.cs`) — porty 6666/6667, stały klucz AES do dekodowania
  pakietów z 6667
- Logowanie do chmury i podpisywanie żądań HMAC-SHA256 (`TuyaCloudClient.cs`)
- 4 komendy: Toggle, Set fixed state, Send custom command, Detect (UDP diagnostyka —
  zastępuje `RefreshDevicesAction`, które w MD2 tylko przeładowywało plik JSON;
  w MD3 urządzenia są zawsze aktualne, bo żyją jako wpisy configu, więc ten przycisk
  stracił sens — zamiast tego dorobiłem prawdziwą diagnostykę UDP z powiadomieniem)

## Największa zmiana architektoniczna — do przetestowania najuważniej

`DeviceManagerForm` (tabelka WinForms z edycją IP/wersji/local key) → **jeden wpis
configu na jedno urządzenie**, przez wieloetapowy `IConfigFlow`
(`ConfigFlow/TuyaConfigFlow.cs`):

```
Krok "kind" → [Konto chmurowe] / [Urządzenie]
  Konto: region/kraj/login/hasło → loguje się i cache'uje listę urządzeń w pamięci
         (TuyaCloudClient.CachedDevices) na czas życia procesu pluginu
  Urządzenie:
    "source" (tylko gdy jest cache z chmury): [Z chmury] / [Ręcznie]
      Z chmury: wybór z listy → auto-uzupełnia id/nazwę/local key
      Ręcznie: id/nazwa/local key wpisywane ręcznie
    "network" (zawsze): IP + wersja protokołu → zapis
```

**To jest część, której nie mogłem przetestować** (nie mam dostępu do bety poza Twoim
środowiskiem) — sam mechanizm wieloetapowego `IConfigFlow` już potwierdziliśmy że
działa (ETS2), ale ten konkretny, dłuższy łańcuch kroków z rozgałęzieniami widzę
pierwszy raz w akcji. Możliwe problemy do sprawdzenia:
- czy `ConfigFlowResult.Error(step, message)` faktycznie cofa na ten sam krok z
  komunikatem błędu (used w kroku logowania przy złym haśle)
- czy pole `Password` (`ActionParameter.Password`) faktycznie maskuje wpisywanie
- czy cache `TuyaCloudClient.CachedDevices` przeżywa między krokami tej samej sesji
  configu (powinien, bo `TuyaCloudClient` to DI singleton, nie coś tworzonego na nowo)

## Świadome uproszczenia względem oryginału

- Brak samego `local_devices.json` — urządzenia żyją jako wpisy configu (`kind=device`),
  konto jako jeden wpis (`kind=account`), rozróżniane po polu `kind`
- `RefreshDevicesAction` zastąpione `DetectDeviceAction` (patrz wyżej)
- Test połączenia z `DeviceManagerForm` nie ma bezpośredniego odpowiednika — `Detect
  device (UDP)` załatwia najważniejszą część (czy urządzenie w ogóle nadaje w sieci)

## Synchronizacja stanu (dwustanowe przyciski)

Dodane po fakcie, więc nie było w oryginalnym MD2 pluginie: `TuyaStatusPollingService`
odpytuje co 3s pole `PrimaryCode` (domyślnie `switch_1`, konfigurowalne per urządzenie
w kroku "Network") każdego urządzenia i publikuje wynik jako zmienną `bool`
`device_<id>_state`. Podepnij ją pod stan dwustanowego przycisku w Macro Decku, żeby
przycisk pokazywał prawdziwy stan nawet po zmianie z aplikacji Tuya na telefonie czy
fizycznym przełącznikiem — nie tylko po naciśnięciu w samym Macro Decku.

Akcje Toggle/Set switch state dodatkowo aktualizują cache natychmiast po udanej
komendzie (nie czekają na najbliższy tick pollingu), więc naciśnięcie przycisku w
samym Macro Decku odświeża się od razu; zmiany z zewnątrz - do 3s opóźnienia.

**Ograniczenie, o którym wcześniej pisałem błędnie**: mówiłem że pomoże restart
pluginu po dodaniu urządzenia — **to było niepoprawne**. Świeży proces powtarza
dokładnie tę samą sekwencję (deklaracja zmiennych do hosta zawsze poprzedza wczytanie
urządzeń z configu), więc restart sam w sobie niczego nie naprawiał. Prawdziwa
poprawka: `TuyaDeviceStore` teraz trzyma dodatkowo lokalny plik-cache
(`%LOCALAPPDATA%\MacroDeck\plugins\com.tabsik12.tuya-control\devices-cache.json`),
wczytywany **synchronicznie w `Program.cs` zanim plugin zacznie się w ogóle łączyć**
— więc nawet pierwsze połączenie świeżego procesu już widzi wcześniej zapisane
urządzenia. Config hosta (`IIntegrationConfig`) zostaje źródłem prawdy — ten plik to
tylko szybki lokalny "bootstrap", odświeżany po każdym udanym zapisie w config flow.

**Nadal jedna sytuacja wymaga restartu**: pierwsze dodanie urządzenia na zupełnie
czystej instalacji (gdy cache jeszcze nie istnieje) — dopiero DRUGI start procesu (po
tym jak `SaveLocalCache()` zdąży zapisać plik) będzie miał je od razu przy deklaracji.

## Test

Po buildzie/instalacji: dodaj konto chmurowe przez config flow, sprawdź czy lista
urządzeń w kroku "Z chmury" się pojawia, dodaj jedno urządzenie, spróbuj akcji Toggle
na nim. Pamiętaj o restarcie Macro Decka po instalacji (znany cache bety).
