using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using TuyaControl.Models;

namespace TuyaControl.Services;

/// <summary>
/// Polls every configured device's PrimaryCode DP on a fixed interval and caches the
/// result in TuyaDeviceStore, so state changes made outside Macro Deck (Tuya app,
/// physical switch, another automation) get picked up and reflected in the device's
/// state variable - which a two-state button can bind to.
///
/// Not a push mechanism - the local LAN protocol here doesn't keep a persistent
/// subscribed connection, so this is polling, not instant. PollInterval trades
/// staleness against LAN/cloud traffic; devices controlled via "cloud" protocol
/// count against Tuya's cloud API rate limits, so don't set this too aggressively
/// if you have many cloud-protocol devices.
/// </summary>
public sealed class TuyaStatusPollingService(
    TuyaDeviceStore store,
    TuyaLocalClient localClient,
    ILogger<TuyaStatusPollingService> logger) : BackgroundService
{
    private static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(3);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            foreach (var device in store.Devices)
            {
                if (stoppingToken.IsCancellationRequested)
                {
                    break;
                }

                await PollOneAsync(device, stoppingToken);
            }

            try
            {
                await Task.Delay(PollInterval, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }
    }

    private async Task PollOneAsync(TuyaDeviceRecord device, CancellationToken cancellationToken)
    {
        try
        {
            var status = await localClient.GetStatusAsync(device, timeoutMs: 2000);
            var value = status[device.PrimaryCode]?.ToObject<bool?>();
            store.SetState(device.Id, value, reachable: true);
        }
        catch (TuyaApiException ex)
        {
            store.SetState(device.Id, null, reachable: false);
            logger.LogDebug("Status poll failed for '{Device}': {Message}", device.Name, ex.Message);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            // shutting down
        }
        catch (Exception ex)
        {
            store.SetState(device.Id, null, reachable: false);
            logger.LogDebug(ex, "Status poll failed unexpectedly for '{Device}'", device.Name);
        }
    }
}
